Run Files with ALL Capital letters 
